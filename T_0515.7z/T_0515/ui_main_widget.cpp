#include "ui_main_widget.h"

ui_main_widget::ui_main_widget(QWidget* parent) : QWidget{parent} {
  init_ui();

  // _thd
  m_thd_calc = new thd_calc;
  auto _func = [=]() { m_thd_calc->run(); };
  std::thread _thd(_func);
  _thd.detach();

  // signals - slots
  connect(btn_start, &QPushButton::clicked, this, [=]() {
    if (register_cvMap(0)) m_thd_calc->resume(true, m_list->count() - 1);
  });
  connect(btn_clear_text, &QPushButton::clicked, this,
          [=]() { system("cls"); });
  connect(m_thd_calc, &thd_calc::sig_finished, this,
          [&](int ui_id) { show_pix(ui_id, 1); });

  connect(btn_add, &QPushButton::clicked, this, &ui_main_widget::step_add);
  connect(btn_insert, &QPushButton::clicked, this,
          &ui_main_widget::step_insert);
  connect(btn_delete, &QPushButton::clicked, this,
          &ui_main_widget::step_delete);
  connect(btn_read_all, &QPushButton::clicked, this,
          &ui_main_widget::file_read);
  connect(btn_write_all, &QPushButton::clicked, this,
          &ui_main_widget::file_write);
  connect(btn_create_by_file, &QPushButton::clicked, this,
          &ui_main_widget::create_by_file);
}

void ui_main_widget::init_ui() {
  setMinimumSize(1300, 600);

  // step_scroll
  QScrollArea* step_scroll = new QScrollArea;
  m_list = new QListWidget;
  step_scroll->setWidgetResizable(true);
  step_scroll->setWidget(m_list);

  // ctrl_widget
  QWidget* ctrl_widget = new QWidget;
  QGridLayout* ctrl_layout = new QGridLayout;
  btn_start = new QPushButton("START");
  btn_add = new QPushButton("add");
  btn_insert = new QPushButton("insert");
  btn_delete = new QPushButton("delete");
  btn_clear_text = new QPushButton("clear_text");
  btn_read_all = new QPushButton("read_all");
  btn_write_all = new QPushButton("write_all");
  btn_create_by_file = new QPushButton("create_by_file");

  ctrl_layout->addWidget(btn_add, 0, 0);
  ctrl_layout->addWidget(btn_insert, 1, 0);
  ctrl_layout->addWidget(btn_delete, 2, 0);
  ctrl_layout->addWidget(btn_start, 1, 3);
  ctrl_layout->addWidget(btn_clear_text, 3, 1);
  ctrl_layout->addWidget(btn_write_all, 4, 0);
  ctrl_layout->addWidget(btn_read_all, 5, 0);
  ctrl_layout->addWidget(btn_create_by_file, 6, 0);
  ctrl_widget->setLayout(ctrl_layout);

  // side_layout = step_scroll + ctrl_widget
  QVBoxLayout* side_layout = new QVBoxLayout;
  side_layout->addWidget(step_scroll, 15, Qt::AlignHCenter);
  side_layout->addStretch(1);
  side_layout->addWidget(ctrl_widget, 1, Qt::AlignHCenter);
  side_layout->addStretch(1);

  // mainLayout
  QHBoxLayout* mainLayout = new QHBoxLayout;
  m_stack = new QStackedWidget;
  m_view = new ui_graphicsview;
  mainLayout->addWidget(m_view, 3, Qt::AlignHCenter);
  mainLayout->addWidget(m_stack, 1, Qt::AlignHCenter);
  mainLayout->addLayout(side_layout, 1);
  mainLayout->setMargin(0);   //���ұ߾�
  mainLayout->setSpacing(0);  // ���¼��
  this->setLayout(mainLayout);

  m_choices = new ui_choices;
}

bool ui_main_widget::register_cvMap(int n) {
  if (m_list->count() < 1) return false;
  cv::Mat src = cv::imread("test.jpg");

  if (src.empty()) {
    std::cout << "test.jpeg is empty" << std::endl;
    return false;
  }
  step_map::instance().register_cvMat(n, src);

  for (int i = 0; i < m_stack->count(); ++i) {
    ui_* w = dynamic_cast<ui_*>(m_stack->widget(i));
    w->register_ui_data();
  }

  return true;
}

void ui_main_widget::step_add() {
  m_choices->exec();  // ģ̬
  ui_* w = m_choices->create();
  if (!w) return;
  QListWidgetItem* item = new QListWidgetItem;

  step_disconnect();  // �Ͽ��ź�
  m_stack->addWidget(w);
  m_list->addItem(item);
  step_connect();  // �ָ��ź�
}

void ui_main_widget::step_insert() {
  m_choices->exec();  // ģ̬
  ui_* w = m_choices->create();
  if (!w) return;
  QListWidgetItem* item = new QListWidgetItem;
  step_disconnect();  // �Ͽ��ź�
  m_list->insertItem(m_list->currentRow(), item);
  m_stack->insertWidget(m_stack->currentIndex(), w);

  step_connect();  // �ָ��ź�
}

void ui_main_widget::step_delete() {
  step_disconnect();  // �Ͽ��ź�
  int n = m_list->currentRow();
  if (n == -1) return;

  _delete_ui(n);
  step_connect();  // �ָ��ź�
}

void ui_main_widget::step_disconnect() {
  disconnect(m_list, 0, 0, 0);
  for (int i = 0; i < m_stack->count(); ++i) {
    ui_* w = dynamic_cast<ui_*>(m_stack->widget(i));
    disconnect(w, 0, this, 0);
  }
}

void ui_main_widget::step_connect() {
  // m_list->setCurrentRow(m_list->count() - 1); // ����
  //
  for (int i = 0; i < m_list->count(); ++i) {
    ui_* w = dynamic_cast<ui_*>(m_stack->widget(i));
    w->register_map(i);  //����ע��id
    w->register_ui_data();
    data_* d = step_map::instance().get_data(i);
    std::string name = std::to_string(i) + " " + d->_name;
    m_list->item(i)->setText(QString::fromStdString(name));
    connect(w, &ui_::sig_show_pix, this, &ui_main_widget::show_pix);

    // ���� =
    connect(w, &ui_::sig_call_single, this, [=]() {
      w->register_ui_data();
      m_thd_calc->resume(false, i);
    });
  }

  //
  connect(m_list, &QListWidget::currentRowChanged, this, [=](int ui_id) {
    m_stack->setCurrentIndex(ui_id);
    show_pix(ui_id, 1);
  });
}
void ui_main_widget::show_pix(int data_id, int mat_serial) {
  QPixmap pix;

  data_* d = step_map::instance().get_data(data_id);
  if (!d) return;
  if (mat_serial == 0)
    pix = cvt_mat::instance().mat2QPixmap(d->_src);
  else if (mat_serial == 1)

    pix = cvt_mat::instance().mat2QPixmap(d->_dst);
  m_view->show_pix(pix);
}

void ui_main_widget::file_read() {
  
  for (int i = 0; i < m_list->count(); ++i) {
    ui_* w = dynamic_cast<ui_*>(m_stack->widget(i));
    w->file_read();
  }
 
}
void ui_main_widget::file_write() {
    MyFile f;
 f.clear();

  for (int i = 0; i < m_list->count(); ++i) {
    ui_* w = dynamic_cast<ui_*>(m_stack->widget(i));
    w->file_write();
  }
}
void ui_main_widget::create_by_file() {
  step_disconnect();  // �Ͽ��ź�

  while (0 != m_list->count()) {
    _delete_ui(0);  //ʼ��Ϊ 0
  }
  MyFile f;
  for (int i = 0;; ++i) {
    std::string _name;
    if (!f.read(std::to_string(i), "_name", _name)) break;
    std::cout << _name << std::endl;
    ui_* w = m_choices->create(_name);
    if (!w) break;

    QListWidgetItem* item = new QListWidgetItem;
    m_stack->addWidget(w);
    m_list->addItem(item);
  }

  step_connect();
  file_read();
}

void ui_main_widget::_delete_ui(int i) {
  QListWidgetItem* item = m_list->item(i);
  m_list->removeItemWidget(item);
  delete item;
  QWidget* widget = m_stack->widget(i);
  m_stack->removeWidget(widget);
  delete widget;
}