#include <QtWidgets/QApplication>

#include "ui_main_widget.h"

int main(int argc, char *argv[]) {
  QApplication a(argc, argv);
  ui_main_widget ui;

  ui.show();
  return a.exec();
}
