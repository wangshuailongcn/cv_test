#pragma once
#include <qboxlayout.h>

struct ui_make_vbox_layout {
  ui_make_vbox_layout(QWidget* main_w) : m_w{main_w} {
    m_box = new QVBoxLayout;
  }

  template <typename W>
  void register_box(W&& w) {
    m_box->addWidget(w);
    m_box->addStretch();
    m_w->setLayout(m_box);
  }

  template <class W, class... Args>
  void register_box(W&& w, Args&&... args) {
    m_box->addWidget(w);
    register_box(args...);
  }

 private:
  QVBoxLayout* m_box;
  QWidget* m_w;
};