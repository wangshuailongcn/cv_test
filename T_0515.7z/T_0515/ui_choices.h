#pragma once

#include <QDialog>
#include <QGridLayout>
#include "ui_canny.h"
#include "ui_cvtColor.h"
#include "ui_morphology.h"
#include "ui_threshold.h"
#include "ui_bitwise_not.h"

class ui_choices : public QDialog {
  Q_OBJECT
 public:
  explicit ui_choices(QWidget* parent = nullptr);
  ~ui_choices();

  ui_* create();
  ui_* create(const std::string& _name);

 private:
  ui_* m_win = nullptr;
  void make_ui(const std::vector<std::string>& btns_name);

protected:
    void closeEvent(QCloseEvent* event);
};
