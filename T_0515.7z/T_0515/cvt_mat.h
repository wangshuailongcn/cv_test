#pragma once

#include <QImage>
#include <QPixmap>

#include "pch_.h"
struct cvt_mat {
	QImage mat2QImage(cv::Mat m);

	QPixmap mat2QPixmap(cv::Mat mat);

	cv::Mat QImage2mat(const QImage& qimage);

	cv::Mat QPixmap2mat(const QPixmap& inPixmap);

	static cvt_mat& instance() {
		static cvt_mat t;
		return t;
	}
};
