#pragma once

#include <qboxlayout.h>
#include <qlistwidget.h>
#include <qpushbutton.h>
#include <qstackedwidget.h>

#include "step_map.h"
#include "thd_calc.h"
#include "ui_choices.h"
#include "ui_graphicsview.h"

class ui_main_widget : public QWidget {
  Q_OBJECT

 public:
  ui_main_widget(QWidget* parent = nullptr);

 private:
  ui_graphicsview* m_view;
  ui_choices* m_choices;
  thd_calc* m_thd_calc;
  QListWidget* m_list;
  QStackedWidget* m_stack;
  QPushButton *btn_start, *btn_clear_text;
  QPushButton *btn_add, *btn_insert, *btn_delete;
  QPushButton *btn_read_all, *btn_write_all;
  QPushButton* btn_create_by_file;

  void _delete_ui(int i);  // ��������
  bool register_cvMap(int n);
  void init_ui();
  void show_pix(int data_id, int mat_serial);
  void step_add();
  void step_insert();
  void step_delete();
  void step_disconnect();
  void step_connect();
  void file_read();
  void file_write();
  void create_by_file();
};
