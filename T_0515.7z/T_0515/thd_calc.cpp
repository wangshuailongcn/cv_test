#include "thd_calc.h"
bool thd_calc::m_pause = false;

void thd_calc::run() {
  while (true) {
    {
      std::unique_lock<std::mutex> lock(m_mutex);
      m_cv.wait(lock, [this] { return !m_pause; });
    }
    if (n_ >= 0) {
      step_map::instance().do_calc(all_, n_);
      emit sig_finished(n_);
    }
    m_pause = true;

    // std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }
}

void thd_calc::resume(bool all, int n) {
  std::unique_lock<decltype(m_mutex)> lck(m_mutex);
  m_pause = false;
  all_ = all;
  n_ = n;
  m_cv.notify_one();
}

bool thd_calc::is_working() { return !m_pause; }