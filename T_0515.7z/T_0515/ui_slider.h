﻿#pragma once
#include <QHBoxLayout>
#include <QLabel>
#include <QSlider>
#include <QSpinBox>

class ui_slider : public QWidget {
  Q_OBJECT
 public:
  ui_slider(QString text = "text", int min = 1, int max = 255,
            int single_step = 1, QWidget* parent = nullptr);

  // get_value
  int operator()();

  // set_value
  void operator()(int);
  void set_text( QString );
 
 private:
 
  QLabel* label_;
  QSlider* slider_;
  QSpinBox* spinBox_;
signals:
    void value_changed(int);

};
