#pragma once

#include "ui_.h"

class ui_threshold : public ui_ {
  Q_OBJECT
 public:
  explicit ui_threshold(int id);
  ~ui_threshold();

  void register_ui_data() override;
  void register_map(int) override;
  void file_write() override;
  void file_read() override;

 private:
     struct Impl;
     std::unique_ptr<Impl> pImpl;


  void init_ui();
  
};
