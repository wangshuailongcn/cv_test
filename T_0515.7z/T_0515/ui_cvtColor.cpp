#include "ui_cvtColor.h"

#include "cv_cvtColor.h"
#include "data_cvtColor.h"

struct ui_cvtColor::Impl : QObject {
  // ����
  std::function<bool(data_*)> func{std::bind(&cv_cvtColor::operator(),
                                             cv_cvtColor::instance(),
                                             std::placeholders::_1)};
  // �������
  QComboBox* box_code;

  // ���������ʼ��
  void init_ui() {
    box_code = new QComboBox;
    box_code->addItem("BGR2GRAY", cv::COLOR_BGR2GRAY);
    box_code->addItem("GRAY2BGR", cv::COLOR_GRAY2BGR);
  }

  bool file_read(data_* p_) {
    auto* p = static_cast<data_cvtColor*>(p_);
    std::string appName{std::to_string(p->_id)};
    MyFile f;
    int n =f.read(appName, "_name", p->_name, appName, "_code",
                               p->_code, appName, "_box_index", p->_box_index);
    if (!n) return false;

    box_code->setCurrentIndex(p->_box_index);
    return true;
  }

  bool file_write(data_* p_) {
    auto* p = static_cast<data_cvtColor*>(p_);
    std::string appName{std::to_string(p->_id)};
    MyFile f;
   return f.write(appName, "_name", p->_name, appName, "_code", p->_code,
                        appName, "_box_index", p->_box_index);
  }

  void register_ui_data(data_* p_) {
    auto* p = static_cast<data_cvtColor*>(p_);
    p->set_param(box_code->currentIndex(), box_code->currentData().toInt());

  }
};

ui_cvtColor::ui_cvtColor(int id) : pImpl(std::make_unique<Impl>()) {
  m_data = new data_cvtColor(-1);
  register_map(id);
  init_ui();
}

ui_cvtColor::~ui_cvtColor() {
  step_map::instance().erase(m_data->_id);
  if (m_data) delete m_data;
  m_data = nullptr;
}

void ui_cvtColor::init_ui() {
  pImpl->init_ui();
  QWidget* w = make_common_ui(m_data);
  ui_make_vbox_layout box(this);
  box.register_box(w, pImpl->box_code);
}

void ui_cvtColor::register_ui_data() { pImpl->register_ui_data(m_data); }

void ui_cvtColor::file_write() { pImpl->file_write(m_data); }
void ui_cvtColor::file_read() {
  ck_continue->setChecked(false);
  pImpl->file_read(m_data);
}

void ui_cvtColor::register_map(int n) {
  step_map::instance().register_map(n, m_data, pImpl->func);
}
