#include "ui_choices.h"

ui_choices::ui_choices(QWidget* parent) : QDialog(parent) {
  std::vector<std::string> btns{

      "cvtColor", "threshold", "bitwise_not", "Canny", "morphology"

  };
  make_ui(btns);
}

ui_* ui_choices::create(const std::string& _name) {
  if (_name == "Canny")
    m_win = new ui_canny(-1);
  else if (_name == "cvtColor")
    m_win = new ui_cvtColor(-1);
  else if (_name == "morphology")
    m_win = new ui_morphology(-1);
  else if (_name == "threshold")
    m_win = new ui_threshold(-1);
  else if (_name == "bitwise_not")
    m_win = new ui_bitwise_not(-1);

  else
    m_win = nullptr;
  return m_win;
}

ui_* ui_choices::create() { return m_win; }

void ui_choices::make_ui(const std::vector<std::string>& btns_name) {
  static int x = 0, y = 0;
  QGridLayout* main_layout = new QGridLayout;
  for (auto& elem : btns_name) {
    QPushButton* btn = new QPushButton(QString::fromStdString(elem));
    main_layout->addWidget(btn, x, ++y);

    connect(btn, &QPushButton::clicked, [=]() {
      create(elem);
      hide();
    });

    if (x == 5) {
      ++x;
      y = 0;
    }
  }
  this->setLayout(main_layout);
}

void ui_choices::closeEvent(QCloseEvent* event) {
  m_win = nullptr;
  std::cout << "cancel create" << std::endl;
}

ui_choices::~ui_choices() { m_win = nullptr; }