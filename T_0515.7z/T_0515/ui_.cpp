#include "ui_.h"


QWidget* ui_::make_common_ui(data_* data) {
  QVBoxLayout* mainLayout = new QVBoxLayout;
  btn_single = new QPushButton("single_start");
  btn_write = new QPushButton("write");
  btn_read = new QPushButton("read");
  btn_src = new QPushButton("src");
  btn_dst = new QPushButton("dst");
  //  QStringLiteral( "��������" )
  ck_continue = new QCheckBox(QStringLiteral("single_continue"));

  connect(btn_single, &QPushButton::clicked, this,
          [=]() { emit sig_call_single(data->_id); });
  connect(btn_src, &QPushButton::clicked, this,
          [=]() { emit sig_show_pix(data->_id, 0); });
  connect(btn_dst, &QPushButton::clicked, this,
          [=]() { emit sig_show_pix(data->_id, 1); });

  connect(btn_write, &QPushButton::clicked, this, [=]() { file_write(); });
  connect(btn_read, &QPushButton::clicked, this, [=]() { file_read(); });
  QWidget* w = new QWidget;
  ui_make_vbox_layout vbox(w);
  vbox.register_box(btn_write, btn_read, ck_continue, btn_single, btn_src,
                    btn_dst);
  return w;
}

 