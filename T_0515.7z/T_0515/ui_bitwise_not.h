#pragma once

#include "cv_bitwise_not.h"
#include "data_bitwise_not.h"
#include "ui_.h"

class ui_bitwise_not : public ui_ {
    Q_OBJECT
public:
    explicit ui_bitwise_not( int id );
    ~ui_bitwise_not();

    void register_ui_data() override;
    void register_map( int ) override;
    void file_write()override;
    void file_read()override;

private:
   
    std::function<bool( data_* )> m_f{ std::bind( &cv_bitwise_not::operator(),
                                              cv_bitwise_not::instance(),
                                              std::placeholders::_1 ) };

   

    void init_ui();
};
