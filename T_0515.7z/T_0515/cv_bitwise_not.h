#pragma once

#include "cv_.h"
#include "data_bitwise_not.h"

class cv_bitwise_not {
public:
    bool operator()( data_* data ) {
        if (!data) {
            std::cout << "data is_not_valid " << std::endl;
            return false;
        }
        auto* p = static_cast<data_bitwise_not*>(data);
        if (p->_src.empty()) {
            std::cout << p->_id << ": src.empty" << std::endl;
            return false;
        }

        cv::bitwise_not( p->_src, p->_dst );
        return true;
    }

    static auto& instance() {
        static cv_bitwise_not t;
        return t;
    }

protected:
    cv_bitwise_not() {}
};
