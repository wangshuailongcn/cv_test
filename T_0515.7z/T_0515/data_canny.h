#pragma once
#include "data_.h"

struct data_canny : public data_ {
  explicit data_canny(int id = -1) {
    _name = "Canny";
    _id = id;
    _src = cv::Mat();
    _dst = cv::Mat();
  }
  void set_param(double threshold1, double threshold2) {
    _threshold1 = threshold1;
    _threshold2 = threshold2;
  }

  double _threshold1{100};
  double _threshold2{200};
};
