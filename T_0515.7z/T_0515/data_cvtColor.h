#pragma once
#include "data_.h"

struct data_cvtColor : public data_ {
  explicit data_cvtColor(int id = -1) {
    _name = "cvtColor";
    _id = id;
    _src = cv::Mat();
    _dst = cv::Mat();
  }
  void set_param(int box_index, int code) {
    box_index = _box_index;
    _code = code;
  }

  int _code{0};
  int _box_index{0};
};
