#pragma once

#include "cv_.h"
#include "data_cvtColor.h"

class cv_cvtColor {
 public:
  bool operator()(data_* data) {
    if (!data) {
      std::cout << "data is_not_valid " << std::endl;
      return false;
    }
    auto* p = static_cast<data_cvtColor*>(data);
    if (p->_src.empty()) {
      std::cout << p->_id << ": src.empty" << std::endl;
      return false;
    }
    cv::cvtColor(p->_src, p->_dst, p->_code);
    return true;
  }

  static auto& instance() {
    static cv_cvtColor t;
    return t;
  }

 protected:
  cv_cvtColor() {}
};
