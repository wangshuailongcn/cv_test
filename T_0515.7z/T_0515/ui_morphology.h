#pragma once

#include "cv_morphology.h"
#include "data_morphology.h"
#include "ui_.h"

class ui_morphology : public ui_ {
  Q_OBJECT
 public:
  explicit ui_morphology(int id);
  ~ui_morphology();

  void register_ui_data() override;
  void register_map(int) override;
  void file_write() override;
  void file_read() override;

 private:
 
 

  void init_ui();
  struct Impl;
  std::unique_ptr<Impl> pImpl;
};
