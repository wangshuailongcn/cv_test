#include "ui_morphology.h"

#include "cv_morphology.h"
#include "data_morphology.h"
struct ui_morphology::Impl : QObject {
  // ��Ա����
  std::function<bool(data_*)> func{std::bind(&cv_morphology::operator(),
                                             cv_morphology::instance(),
                                             std::placeholders::_1)};

  ui_slider *slider_k, *slider_iterations, *slider_op;

  // ���������ʼ��
  void init_ui() {
    slider_k = new ui_slider("k", 1, 7, 1);
    slider_op = new ui_slider("op", 0, 8, 1);
    slider_iterations = new ui_slider("iters", 1, 5, 1);
    connect(slider_op, &ui_slider::value_changed, this, [=](int n) {
      QString text{""};
      if (n == 0)
        text = "0MORPH_ERODE";
      else if (n == 1)
        text = "1MORPH_DILATE";
      else if (n == 2)
        text = "2MORPH_OPEN";
      else if (n == 3)
        text = "3MORPH_CLOSE";
      else if (n == 4)
        text = "4MORPH_GRADIENT";
      else if (n == 5)
        text = "5MORPH_TOPHAT";
      else if (n == 6)
        text = "6MORPH_BLACKHAT";
      else if (n == 7)
        text = "7MORPH_HITMISS";
      else if (n == 8)
        text = "_MORPH_boundary";

      slider_op->set_text(text);
    });
  }

  void register_ui_data(data_* p_) {
    data_morphology* p = static_cast<data_morphology*>(p_);
    p->set_param((*slider_op)(), (*slider_k)(), (*slider_iterations)());
  }
  bool file_write(data_* p_) {
    data_morphology* p = static_cast<data_morphology*>(p_);

    std::string appName{std::to_string(p->_id)};
    MyFile f;
    return f.write(appName, "_name", p->_name, appName, "_op",
                               p->_op, appName, "_k", p->_k, appName,
                               "_iterations", p->_iterations);
  }

  bool file_read(data_* p_) {
    data_morphology* p = static_cast<data_morphology*>(p_);
    std::string appName{std::to_string(p->_id)};
    MyFile f;
    int n = f.read(appName, "_name", p->_name, appName, "_op",
                               p->_op, appName, "_k", p->_k, appName,
                               "_iterations", p->_iterations);
    if (!n) return false;

    (*slider_k)(p->_k);
    (*slider_op)(p->_op);
    (*slider_iterations)(p->_iterations);
    return true;
  }
};

ui_morphology::ui_morphology(int id) : pImpl(std::make_unique<Impl>()) {
  m_data = new data_morphology(-1);
  register_map(id);
  init_ui();
}

ui_morphology::~ui_morphology() {
  step_map::instance().erase(m_data->_id);
  if (m_data) delete m_data;
  m_data = nullptr;
}

void ui_morphology::init_ui() {
  pImpl->init_ui();

  QWidget* w = make_common_ui(m_data);
  ui_make_vbox_layout box(this);
  box.register_box(w, pImpl->slider_k, pImpl->slider_op,
                   pImpl->slider_iterations);

  real_time_show(pImpl->slider_k, pImpl->slider_op, pImpl->slider_iterations);
}

void ui_morphology::register_ui_data() { pImpl->register_ui_data(m_data); }

void ui_morphology::file_write() { pImpl->file_write(m_data); }
void ui_morphology::file_read() {
  ck_continue->setChecked(false);
  pImpl->file_read(m_data);
}

void ui_morphology::register_map(int n) {
  step_map::instance().register_map(n, m_data, pImpl->func);
}
