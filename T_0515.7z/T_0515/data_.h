#pragma once
#include "pch_.h"
struct data_ {
    data_() {}
    std::string _name{ "data_" };
    int _id{ -1 };
    cv::Mat _src = cv::Mat();
    cv::Mat _dst = cv::Mat();
};
