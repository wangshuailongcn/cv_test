#pragma once
#include "data_.h"

struct data_morphology : public data_ {
  explicit data_morphology(int id = -1) {
    _name = "morphology";
    _id = id;
    _src = cv::Mat();
    _dst = cv::Mat();
  }
  void set_param(int op, int k, int iterations) {
    _op = op;
    _k = k;
    _iterations = _iterations;
  }

  int _op{0};
  int _k{1};
  double _iterations{1};
};
