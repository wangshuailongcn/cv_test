#pragma once

#include <qcombobox.h>

#include <QCheckBox>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QPushButton>
#include <QVBoxLayout>
#include <memory>

#include "cvt_mat.h"
#include "data_.h"
#include "my_file.h"
#include "step_map.h"
#include "thd_calc.h"
#include "ui_make_vbox_layout.h"
#include "ui_slider.h"

class ui_ : public QWidget {
  Q_OBJECT
 public:
  virtual ~ui_(){};

  virtual void register_map(int) = 0;
  virtual void register_ui_data() = 0;
  virtual void file_write() = 0;
  virtual void file_read() = 0;

  // virtual QPixmap get_pix(int data_id, int mat_serial);

 protected:
  QWidget* make_common_ui(data_* data);

  QPushButton *btn_write, *btn_read;
  QPushButton *btn_src, *btn_dst;
  QPushButton* btn_single;
  QCheckBox* ck_continue;

  data_* m_data;
 signals:
  void sig_show_pix(int ui_id, int mat_serial);
  void sig_call_single(int ui_id);

 public:
  template <typename Slider>
  void real_time_show(Slider& w) {
    static_assert(!std::is_base_of_v<ui_slider, std::decay_t<Slider>>,

                  "ui real_time_show Slider type error");

    connect(w, &ui_slider::value_changed, this, [=](int) {
      if (!ck_continue->isChecked()) return;
      if (!thd_calc::m_pause) return;
      register_ui_data();
      emit sig_call_single(m_data->_id);
    });
  }

  template <class Slider, class... Args>
  void real_time_show(Slider& w, Args&... args) {
    real_time_show(w);
    real_time_show(args...);
  }
};
