#pragma once

#include "cv_.h"
#include "data_morphology.h"

class cv_morphology {
 public:
  bool operator()(data_* data) {
    if (!data) {
      std::cout << "data is_not_valid " << std::endl;
      return false;
    }
    auto* p = static_cast<data_morphology*>(data);
    if (p->_src.empty()) {
      std::cout << p->_id << ": src.empty" << std::endl;
      return false;
    }
    
    int k = p->_k * 2 + 1;
    cv::Mat element = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(k, k),
                                                cv::Point(-1, -1));

    // ��̬ѧ��ȡ
    if (p->_op == _MORPH_boundary) {
      erode(p->_src, p->_dst, element);
      p->_dst = p->_src - p->_dst;
      return true;
    }

    cv::morphologyEx(p->_src, p->_dst, p->_op, element, cv::Point(-1, -1),
                     p->_iterations);

    return true;
  }

  static auto& instance() {
    static cv_morphology t;
    return t;
  }

 protected:
  cv_morphology() {}
};
