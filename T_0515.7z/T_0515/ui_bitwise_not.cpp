#include "ui_bitwise_not.h"

ui_bitwise_not::ui_bitwise_not(int id) {
 
  m_data = new data_bitwise_not(-1);
  register_map(id);
  init_ui();
}

ui_bitwise_not::~ui_bitwise_not() {
  step_map::instance().erase(m_data->_id);
  if (m_data) delete m_data;
  m_data = nullptr;
}

void ui_bitwise_not::init_ui() {
  QWidget* w = make_common_ui(m_data);
  ui_make_vbox_layout box(this);
  box.register_box(w);
}

void ui_bitwise_not::register_ui_data() {}

void ui_bitwise_not::file_write() {}
void ui_bitwise_not::file_read() {}

void ui_bitwise_not::register_map(int n) {
  step_map::instance().register_map(n, m_data, m_f);
  // register_ui_data(); //ʱ��
}
