#pragma once
#include "data_.h"

struct data_bitwise_not : public data_ {
  explicit data_bitwise_not(int id = -1) {
    _name = "bitwise_not";
    _id = id;
    _src = cv::Mat();
    _dst = cv::Mat();
  }
  void set_param() { return; }
};
