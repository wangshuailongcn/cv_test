#include "ui_threshold.h"

#include "cv_threshold.h"
#include "data_threshold.h"
struct ui_threshold::Impl : QObject {
  // ��Ա����
  std::function<bool(data_*)> func{std::bind(&cv_threshold::operator(),
                                             cv_threshold::instance(),
                                             std::placeholders::_1)};
  ui_slider *slider_max, *slider_thresh, *slider_type;

  // ���������ʼ��
  void init_ui() {
    slider_max = new ui_slider("max", 0, 255, 1);
    slider_thresh = new ui_slider("thresh", 0, 255, 1);
    slider_type = new ui_slider("type", 0, 4, 1);

    connect(slider_type, &ui_slider::value_changed, this, [=](int n) {
      // THRESH_MASK = 7,
      // THRESH_OTSU = 8, //!< flag, use Otsu algorithm to choose the optimal
      // threshold value
      // THRESH_TRIANGLE = 16 //!< flag, use Triangle algorithm to choose the
      // optimal threshold value
      QString text{""};
      if (n == 0)
        text = "0THRESH_BINARY";
      else if (n == 1)
        text = "1THRESH_BINARY_INV";
      else if (n == 2)
        text = "2THRESH_TRUNC";
      else if (n == 3)
        text = "3THRESH_TOZERO";
      else if (n == 4)
        text = "4THRESH_TOZERO_INV";

      slider_type->set_text(text);
    });
  }

  // read
  bool file_read(data_* p_) {
    auto* p = static_cast<data_threshold*>(p_);
    std::string appName{std::to_string(p->_id)};
    MyFile f;
    int n = f.read(appName, "_name", p->_name,

                               appName, "_max", p->_max, appName, "_thresh",
                               p->_thresh, appName, "_type", p->_type);
    if (!n) return false;

    (*slider_max)(p->_max);
    (*slider_thresh)(p->_thresh);
    (*slider_type)(p->_type);
    return true;
  }

  // write
  bool file_write(data_* p_) {
    auto* p = static_cast<data_threshold*>(p_);
    std::string appName{std::to_string(p->_id)};
    MyFile f;
    return f.write(appName, "_name", p->_name,

                               appName, "_max", p->_max, appName, "_thresh",
                               p->_thresh, appName, "_type", p->_type);
  }

  //  register_ui_data
  void register_ui_data(data_* p_) {
    auto* p = static_cast<data_threshold*>(p_);
    p->set_param((*slider_thresh)(), (*slider_max)(), (*slider_type)());
  }
};

ui_threshold::ui_threshold(int id) : pImpl(std::make_unique<Impl>()) {
  m_data = new data_threshold(-1);
  register_map(id);
  init_ui();
}

ui_threshold::~ui_threshold() {
  step_map::instance().erase(m_data->_id);
  if (m_data) delete m_data;
  m_data = nullptr;
}

void ui_threshold::init_ui() {
  pImpl->init_ui();
  QWidget* w = make_common_ui(m_data);
  ui_make_vbox_layout box(this);
  box.register_box(w, pImpl->slider_max, pImpl->slider_thresh,
                   pImpl->slider_type);

  real_time_show(pImpl->slider_max, pImpl->slider_thresh, pImpl->slider_type);
}

void ui_threshold::register_ui_data() { pImpl->register_ui_data(m_data); }

void ui_threshold::file_write() { pImpl->file_write(m_data); }
void ui_threshold::file_read() {
  ck_continue->setChecked(false);
  pImpl->file_read(m_data);
}

void ui_threshold::register_map(int n) {
  step_map::instance().register_map(n, m_data, pImpl->func);
}
