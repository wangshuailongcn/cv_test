#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <Windows.h>

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

class MyFile {
 private:
  char m_fileName[MAX_PATH] = "./default_ini.ini";

 public:
  void set_default_file(const std::string& new_file) {
    memset(m_fileName, '\0', sizeof(m_fileName));
    auto end = min(MAX_PATH, new_file.size());
    std::copy(new_file.begin(), new_file.begin() + end, m_fileName);
  }

  template <class V>
  int read(const std::string& appName, const std::string& keyName, V& v) {
    static_assert(std::is_fundamental_v<std::remove_reference_t<V>> ||
                      std::is_constructible_v<std::string, V>,
                  "MyFile V type error");
    char buf[MAX_PATH];
    int len = GetPrivateProfileStringA(appName.c_str(), keyName.c_str(), "",
                                       buf, sizeof buf, m_fileName);
    if (len) {
      std::string str{buf};
      std::istringstream iss(str);
      iss >> v;
    }
    return len;
  }

  template <class V, class... Next>
  int read(const std::string& appName, const std::string& keyName, V& v,
           Next&&... params) {
    int n = read(appName, keyName, v);
    if (!n) return n;

    return read(params...);
  }

  template <class V>
  int write(const std::string& appName, const std::string& keyName, V&& v) {
    static_assert(std::is_fundamental_v<std::remove_reference_t<V>> ||
                      std::is_constructible_v<std::string, V>,
                  "MyFile V type error");
    std::ostringstream oss;
    oss << std::forward<V>(v);
    return WritePrivateProfileStringA(appName.c_str(), keyName.c_str(),
                                      oss.str().c_str(), m_fileName);
  }

  template <class V, class... Next>
  int write(const std::string& appName, const std::string& keyName, V&& v,
            Next&&... params) {
    int n = write(appName, keyName, v);
    if (!n) return n;

    return write(params...);
  }

  void clear() {
    std::ofstream OutFile(m_fileName);
    OutFile << "";
    OutFile.close();
  }
};

//#include<QString>
//#include<QSettings>
// class file_impl_2 {
//
//    file_impl_2(const QString& path)
//    {
//        file = new  QSettings(path, QSettings::IniFormat);
//        file->setIniCodec("UTF8");
//    }
//    QVariant  read(const QString& key, const QVariant& dft)
//    {
//        return file->value(key, dft);
//    }
//    void  write(const QString& key, const QVariant& dft)
//    {
//        file->setValue(key, dft);
//    }
// private:
//    QSettings* file;
//};
