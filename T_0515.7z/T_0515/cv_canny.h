#pragma once

#include "cv_.h"
#include "data_canny.h"

class cv_canny {
 public:
  bool operator()(data_* data) {
    if (!data) {
      std::cout << "data is_not_valid " << std::endl;
      return false;
    }
    auto* p = static_cast<data_canny*>(data);
    if (p->_src.empty()) {
      std::cout << p->_id << ": src.empty" << std::endl;
      return false;
    }
 
    cv::Canny(p->_src, p->_dst, p->_threshold1, p->_threshold2);
    return true;
  }

  static auto& instance() {
    static cv_canny t;
    return t;
  }

 protected:
  cv_canny() {}
};
