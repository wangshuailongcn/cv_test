#pragma once

#include <qobject.h>

#include <condition_variable>
#include <thread>

#include "step_map.h"

class thd_calc : public QObject {
  Q_OBJECT
 public:
  void run();
  void resume(bool all, int n);
  bool is_working();
  static bool m_pause;

 private:
  std::condition_variable m_cv;
  std::mutex m_mutex;

  bool all_;
  int n_;

 signals:
  void sig_finished(int ui_id);
};
