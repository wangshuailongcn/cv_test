#pragma once


#include "ui_.h"

class ui_cvtColor : public ui_ {
  Q_OBJECT
 public:
  explicit ui_cvtColor(int id);
  ~ui_cvtColor();

  void register_ui_data() override;
  void register_map(int) override;
  void file_write() override;
  void file_read() override;

 private:
  void init_ui();

  struct Impl;
  std::unique_ptr<Impl> pImpl;
};
