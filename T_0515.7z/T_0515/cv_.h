#pragma once

#include "data_.h"
constexpr auto _MORPH_boundary = 8;
