﻿#pragma once
#include "data_.h"

class step_map {
 public:
  void register_map(int n, data_* d, std::function<bool(data_*)> f);
  void register_map(int n, data_* d);
  void register_map(int n, std::function<bool(data_*)> f);
  void register_cvMat(int n, const cv::Mat&);

  data_* get_data(int n);
  std::function<bool(data_*)>& get_func(int n);

  bool do_calc(bool all, int n);

  void erase(int n);

  static step_map& instance() {
    static step_map t;
    return t;
  }

 private:
  std::unordered_map<int, data_*> m_data;
  std::unordered_map<int, std::function<bool(data_*)>> m_func;

 protected:
  step_map() {}
};
