﻿#pragma once
#include <QGraphicsPixmapItem>
#include <QGraphicsView>
#include <QWheelEvent>
#include <QWidget>

class ui_graphicsview : public QGraphicsView {
  Q_OBJECT

 public:

  ui_graphicsview(QWidget* parent = nullptr);

  void show_pix(const QPixmap&);

  void setDrawType(int type);

 protected:
  //缩放
  qreal zoom = 1.;
  void wheelEvent(QWheelEvent* event);

  // 平移
  QPoint m_firstMousePos, m_lastMousePos;
  bool bMouseE;
  void mouseMoveEvent(QMouseEvent* event);
  void mousePressEvent(QMouseEvent* event);
  void mouseReleaseEvent(QMouseEvent*);
  void mouseDoubleClickEvent(QMouseEvent*);

 private:
	 QPixmap *m_pix;
  int myDrawType = 0;
  enum myDrawEnum { drawNull = 0, drawRect = 1 };
  bool isDraw = false;
  QGraphicsScene* myScene;
  QGraphicsPixmapItem* myPixmapItem;
  QGraphicsRectItem* rect1;
  QGraphicsTextItem* textFirstPos;
  QGraphicsTextItem* textLastPos;
};
