#pragma once
#include "data_.h"

struct data_threshold : public data_ {
  explicit data_threshold(int id = -1) {
    _name = "threshold";
    _id = id;
    _src = cv::Mat();
    _dst = cv::Mat();
  }
  void set_param(int thresh, int max, int type) {
    _thresh = thresh;
    _max = max;
    _type = type;
  }

  int _thresh{0};
  int _max{255};
  double _type{0};
};
