#include "ui_canny.h"

#include "cv_canny.h"
#include "data_canny.h"
struct ui_canny::Impl:QObject {
  // ����
  std::function<bool(data_*)> func{std::bind(
      &cv_canny::operator(), cv_canny::instance(), std::placeholders::_1)};

  // �������
  ui_slider *slider1, *slider2;

  // ���������ʼ��
  void init_ui() {
    slider1 = new ui_slider("[1]");
    slider2 = new ui_slider("[2]");
  }

  void register_ui_data(data_* p_) {
    data_canny* p = static_cast<data_canny*>(p_);
    p->set_param((*slider1)(), (*slider2)());
  }
  bool file_write(data_* p_) {
    data_canny* p = static_cast<data_canny*>(p_);
    std::string appName{std::to_string(p->_id)};
    MyFile f;
    return f.write(appName, "_name", p->_name, appName,
                               "_threshold1", p->_threshold1, appName,
                               "_threshold2", p->_threshold2);
  }

  bool file_read(data_* p_) {
    data_canny* p = static_cast<data_canny*>(p_);
    std::string appName{std::to_string(p->_id)};
    MyFile f;
    int n =f.read(appName, "_name", p->_name, appName,
                               "_threshold1", p->_threshold1, appName,
                               "_threshold2", p->_threshold2);

    if (!n) return false;

    (*slider1)(p->_threshold1);
    (*slider2)(p->_threshold2);
    return true;
  }
};

ui_canny::ui_canny(int id) : pImpl(std::make_unique<Impl>()) {
  m_data = new data_canny(id);
  register_map(id);
  init_ui();
}

ui_canny::~ui_canny() {
  step_map::instance().erase(m_data->_id);
  if (m_data) delete m_data;
  m_data = nullptr;
}

void ui_canny::init_ui() {
  pImpl->init_ui();

  QWidget* w = make_common_ui(m_data);

  ui_make_vbox_layout box(this);
  box.register_box(w, pImpl->slider1, pImpl->slider2);

  real_time_show(pImpl->slider1, pImpl->slider2);
}

void ui_canny::register_ui_data() { pImpl->register_ui_data(m_data); }

void ui_canny::file_write() { pImpl->file_write(m_data); }
void ui_canny::file_read() {
  ck_continue->setChecked(false);
  pImpl->file_read(m_data);
}

void ui_canny::register_map(int n) {
  step_map::instance().register_map(n, m_data, pImpl->func);
}
