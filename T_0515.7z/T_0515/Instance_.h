//#pragma once

// namespace tools
//namespace {
//namespace tools {
//template <typename T>
//T* Instance(T*) {
//  return new T;
//}

// template <typename T, typename... Args>
// T* Instance(Args&&... args) {
//  return new T(std::forward<Args>(args)...);
//}
//
//}  // namespace tools
//}  // namespace