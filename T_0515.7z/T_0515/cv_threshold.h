#pragma once
#include "cv_.h"
#include "data_threshold.h"

class cv_threshold {
 public:
  bool operator()(data_* data) {
    if (!data) {
      std::cout << "data is_not_valid " << std::endl;
      return false;
    }
    auto* p = static_cast<data_threshold*>(data);
    if (p->_src.empty()) {
      std::cout << p->_id << ": src.empty" << std::endl;
      return false;
    }
    //
    cv::threshold(p->_src, p->_dst, p->_thresh, p->_max, p->_type);

    return true;
  }

  static auto& instance() {
    static cv_threshold t;
    return t;
  }

 protected:
  cv_threshold() {}
};
