#include "step_map.h"

void step_map::register_map(int n, data_* d,
                            std::function<bool(data_*)> f) {
  register_map(n, d);
  register_map(n, f);
}

void step_map::register_map(int n, data_* d) {
  d->_id = n;
  m_data[n] = d;
}

void step_map::register_map(int n, std::function<bool(data_*)> f) {
  m_func[n] = f;
}
data_* step_map::get_data(int n) { return m_data[n]; }
std::function<bool(data_*)>& step_map::get_func(int n) {
  return m_func[n];
}

void step_map::register_cvMat(int n, const cv::Mat& m)
{
    m_data[n]->_src = m.clone(); 
}

void step_map::erase(int n) {
  m_data.erase(n);
  m_func.erase(n);
}

bool step_map::do_calc(bool all, int n) {
    if (n < 0)return false;
  cv::Mat dst;
  if (all) {
    for (int i = 0; i <= n; ++i) {
      data_* d = m_data[i];
      try {
        if (i != 0) d->_src = dst;
        m_func[i](d); // i
      } catch (...) {
        std::cerr << "ִ�м��� error " << i << std::endl;
        return false;
      }
      if (i != n) dst = d->_dst;
    }
    return true;
  }
  // -------------------------------------
  data_* d = m_data[n];
  try {
    m_func[n](d); //n
  } catch (...) {
    std::cerr << "ִ�м��� x  " << n << std::endl;
    return false;
  }
  // -------------------------------------
  n++;
  if (m_data[n]) m_data[n]->_src = d->_dst;
  return true;
}
