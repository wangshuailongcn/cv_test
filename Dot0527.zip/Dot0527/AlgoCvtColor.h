#pragma once
#include "IData.h"
namespace {

bool AlgoCvtColor(IData* d) {
  if (!d->srcEmpty()) return false;

 
  int code = d->vec[0];
 
  cv::cvtColor(d->src, d->dst, code);

  return true;
}

}  // namespace