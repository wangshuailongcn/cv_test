#pragma once
#include "IData.h"
namespace {

bool AlgoThreshold(IData* d) {
  if (!d->srcEmpty()) return false;
  int i=0;
 
  int thresh = d->vec[i++];
  int max = d->vec[i++];
  int type = d->vec[i++];

  cv::threshold( d->src, d->dst, thresh, max, type);

  return true;
}

}  // namespace