#pragma once

#include "IData.h"
namespace {

// ��ɫ����
void removePepperNoise(cv::Mat& m, int kSize);

bool AlgoPepperNoise(IData* d) {
  if (!d->srcEmpty()) return false;

  int k = d->vec[0] * 4 + 1;
  d->dst = d->src.clone();

  // r2( d->dst );
  removePepperNoise(d->dst, k);

  return true;
}

void removePepperNoise(cv::Mat& src, int kSize) {
  int half = (kSize - 1) / 2;
  std::unique_ptr<uchar*[]> pRow(new uchar*[kSize]);

  for (int y = half; y < src.rows - half; ++y) {
    for (int n = 0; n != kSize; ++n) {
      // Skip the first (and last) kSize/2 pixels on each row.
      pRow[n] = src.ptr(y - half + n);  //Ĭ�� uchar* ����ģ�� .ptr (int)
      pRow[n] += half;
    }
    for (int x = half; x < src.cols - half; ++x) {
      uchar value = *pRow[half];  // ����ֵ
      // Check if it's a black pixel surrounded bywhite
      // pixels (ie: whether it is an "island" of black).
      if (value == 0) {
        bool above, left, below, right, surroundings;
        above = left = below = right = surroundings = true;

        uchar* p_above = pRow.get()[0];
        uchar* p_below = pRow.get()[kSize - 1];
        for (int n = -half; n <= half; ++n) {
          above = above && *(p_above + n);
          below = below && *(p_below + n);
        }

        for (int n = 1; n <= kSize - 2; ++n) {
          uchar* p_left = pRow.get()[n];
          left = left && *(p_left - half);

          uchar* p_right = pRow.get()[n];
          right = right && *(p_right + half);
        }

        surroundings = above && left && below && right;

        if (surroundings) {
          // Fill the whole kSize block as white. Since we
          // knowthe kSize borders are already white, we just
          // need tofill the (k-2)*(k-2) inner region.
          for (int y = 1; y <= kSize - 2; ++y) {
            for (int x = -half + 1; x <= half - 1; ++x) {
              *(pRow.get()[y] + x) = 255;
            }
          }

          // Since we just covered the whole 5x5 block with
          // white, we know the next 2 pixels won't be
          // black,so skip the next 2 pixels on the right.
          for (int n = 0; n <= kSize - 1; ++n) {
            pRow[n] += half;
          }
        }
      }
      // Move to the next pixel on the right.
      for (int n = 0; n <= kSize - 1; ++n) {
        ++pRow[n];
      }
    }
  }
  // cv:imshow( "", src );
  //  cv::waitKey();
}

}  // namespace

// void r2(cv::Mat& mask) {
//  using namespace cv;
//  for (int y = 2; y < mask.rows - 2; y++) {
//    // Get access to each of the 5 rows near this pixel.
//    uchar* pUp2 = mask.ptr(y - 2);
//    uchar* pUp1 = mask.ptr(y - 1);
//    uchar* pThis = mask.ptr(y);
//    uchar* pDown1 = mask.ptr(y + 1);
//    uchar* pDown2 = mask.ptr(y + 2);
//    // Skip the first (and last) 2 pixels on each row.
//    pThis += 2;
//    pUp1 += 2;
//    pUp2 += 2;
//    pDown1 += 2;
//    pDown2 += 2;
//    for (auto x = 2; x < mask.cols - 2; x++) {
//      uchar value = *pThis;  // Get pixel value (0 or 255).
//                             // Check if it's a black pixel surrounded bywhite
//
//      // pixels (ie: whether it is an "island" of black).
//      if (value == 0) {
//        bool above, left, below, right, surroundings;
//        above =
//            *(pUp2 - 2) && *(pUp2 - 1) && *(pUp2) && *(pUp2 + 1) && *(pUp2 +
//            2);
//        left = *(pUp1 - 2) && *(pThis - 2) && *(pDown1 - 2);
//        below = *(pDown2 - 2) && *(pDown2 - 1) && (pDown2) && (pDown2 + 1) &&
//                *(pDown2 + 2);
//        right = *(pUp1 + 2) && *(pThis + 2) && *(pDown1 + 2);
//        surroundings = above && left && below && right;
//        if (surroundings == true) {
//          // Fill the whole 5x5 block as white. Since we
//          // knowthe 5x5 borders are already white, we just
//          // need tofill the 3x3 inner region.
//          *(pUp1 - 1) = 255;
//          *(pUp1 + 0) = 255;
//          *(pUp1 + 1) = 255;
//          *(pThis - 1) = 255;
//          *(pThis + 0) = 255;
//          *(pThis + 1) = 255;
//          *(pDown1 - 1) = 255;
//          *(pDown1 + 0) = 255;
//          *(pDown1 + 1) = 255;
//          // Since we just covered the whole 5x5 block with
//          // white, we know the next 2 pixels won't be
//          // black,so skip the next 2 pixels on the right.
//          pThis += 2;
//          pUp1 += 2;
//          pUp2 += 2;
//          pDown1 += 2;
//          pDown2 += 2;
//        }
//      }
//      // Move to the next pixel on the right.
//      pThis++;
//      pUp1++;
//      pUp2++;
//      pDown1++;
//      pDown2++;
//    }
//  }
//}
