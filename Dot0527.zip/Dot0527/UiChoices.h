#pragma once
 
#include "UiVbox.h"

class UiChoices : public QDialog {
  Q_OBJECT
 public:
  explicit UiChoices(QWidget* parent = nullptr);
  ~UiChoices();

  UiVbox* create();
  UiVbox* create(const std::string& _name);

 private:
	 UiVbox* m_win = nullptr;
  void make_ui(const std::vector<std::string>& btns_name);

 protected:
  void closeEvent(QCloseEvent* event);
};
