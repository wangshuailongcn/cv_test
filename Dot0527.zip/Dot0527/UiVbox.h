#pragma once
#include "IData.h"
#include "UiSlider.h"
#include "MyFile.h"

class UiVbox : public QWidget {
  Q_OBJECT
 public:
  UiVbox();
  ~UiVbox();

  // ע��data fn 
  void setId(int id) {
    m_data->id = id;
    g_data[id] = m_data;
    g_fn[id] = m_fn;
  }

  // ��д�������vec[]
  void flushParam();

  UiVbox* getBox();

  // ���뻬����
  void add(int id, QString text, int min, int max, int single_step);

  template <class... Args>
  void add(int id, QString text, int min, int max, int single_step,
           Args&&... args) {

    add_1(id, text, min, max, single_step);
    add(std::forward<Args>(args)...);
  }

  // remove������
  void removeAll();

  void fileWrite(); 
  void fileRead();
public:
  IData* m_data;
  std::function<bool(IData*)> m_fn;

 private:
  QVBoxLayout* m_layout;

  void add_1(int id, QString text, int min, int max, int single_step);

  QPushButton *btn_write, *btn_read;
  QPushButton *btn_src, *btn_dst;
  QPushButton* btn_single;
  QCheckBox* ck_continue;
  QWidget* makeCommonUi();

 signals:
  void sig_show_pix(int ui_id, int mat_serial);
 signals:
  void sig_call_single(int ui_id);
};