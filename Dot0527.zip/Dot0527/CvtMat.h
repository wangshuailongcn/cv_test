#pragma once

#include <QImage>
#include <QPixmap>

#include "Pch.h"
struct CvtMat { 
	QImage mat2QImage(cv::Mat m);

	QPixmap mat2QPixmap(cv::Mat mat);

	cv::Mat QImage2mat(const QImage& qimage);

	cv::Mat QPixmap2mat(const QPixmap& inPixmap);

	static CvtMat& instance() {
		static CvtMat t;
		return t;
	}
};
