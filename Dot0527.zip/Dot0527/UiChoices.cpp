#include "UiChoices.h"

#include "AlgoBitwiseNot.h"
#include "AlgoCanny.h"
#include "AlgoCvtColor.h"
#include "AlgoMorphology.h"
#include "AlgoPepperNoise.h"
#include "AlgoThreshold.h"

UiChoices::UiChoices(QWidget* parent) : QDialog(parent) {
    setFixedWidth( 1024 );
  std::vector<std::string> btns{

      "cvtColor_001",   "threshold_002", "bitwise_not_003",
      "morphology_004", "Canny_005",     "contrast_stretch_006",
      "pepperNoise_007"

  };
  make_ui(btns);
}

UiVbox* UiChoices::create(const std::string& name_) {
  m_win = nullptr;
  UiVbox* box = new UiVbox;
  int i = 0;
  // ------------------------------------------------------------------
  // ***************       �޸Ĳ���         ***************
  // ***************       �޸Ĳ���         ***************
  // ***************       �޸Ĳ���         ***************
  // ------------------------------------------------------------------
  if (name_ == "cvtColor_001") {
    box->add(i++, "6 | 8", 6, 8, 2  //

    );
    box->m_fn = [](IData* d) { return AlgoCvtColor(d); };

  }
  //
  else if (name_ == "threshold_002") {
    box->add(i++, "thresh", 0, 255, 1,  //
             i++, "max", 0, 255, 1,     //
             i++, "type", 0, 4, 1       //
    );
    box->m_fn = [](IData* d) { return AlgoThreshold(d); };
  }
  //
  else if (name_ == "bitwise_not_003") {
    box->add(i++, "0 | 1", 0, 1, 1  //
    );
    box->m_fn = [](IData* d) { return AlgoBitwiseNot(d); };
  }
  //
  else if (name_ == "morphology_004") {
    box->add(i++, "k", 1, 7, 1,     //
             i++, "op", 0, 8, 1,    //
             i++, "iters", 1, 5, 1  //
    );
    box->m_fn = [](IData* d) { return AlgoMorphology(d); };
  }
  //
  else if (name_ == "Canny_005") {
    box->add(i++, "1", 0, 500, 1,  //
             i++, "2", 0, 500, 1   //
    );
    box->m_fn = [](IData* d) { return AlgoCanny(d); };
  }
  //
  //
  else if (name_ == "pepperNoise_007") {
    box->add(i++, "k", 2, 7, 1);
    box->m_fn = [](IData* d) { return AlgoPepperNoise(d); };
  }
  //
  //
  //
  //
  //
  //
  // ------------------------------------------------------------------
  // ***************       ���Ĳ���         ***************
  // ***************       ���Ĳ���         ***************
  // ***************       ���Ĳ���         ***************
  // ------------------------------------------------------------------

  else {
    delete box;
    box = nullptr;
    return box;
  }
  box->m_data->name = name_;
  m_win = box->getBox();
  return m_win;
}

UiVbox* UiChoices::create() { return m_win; }

void UiChoices::make_ui(const std::vector<std::string>& btns_name) {
  static int x = 0, y = 0;
  QGridLayout* main_layout = new QGridLayout;
  for (auto& elem : btns_name) {
    QPushButton* btn = new QPushButton(QString::fromStdString(elem));
     btn->setFixedWidth(120);
    main_layout->addWidget(btn, x, ++y);

    connect(btn, &QPushButton::clicked, [=]() {
      create(elem);
      hide();
    });

    if (y == 9) {
      ++x;
      y = 0;
    }
  }
 
  this->setLayout(main_layout);
}

void UiChoices::closeEvent(QCloseEvent* event) {
  m_win = nullptr;
  std::cout << "cancel create" << std::endl;
}

UiChoices::~UiChoices() { m_win = nullptr; }