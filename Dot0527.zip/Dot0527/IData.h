#pragma once
#include "Pch.h"

struct IData;
extern std::unordered_map<int, IData*> g_data;
extern std::unordered_map<int, std::function<bool(IData*)>> g_fn;

struct IData {
  IData() { vec.resize(10); }
  ~IData() {}
  std::string name{"IData"};
  cv::Mat src = cv::Mat();
  cv::Mat dst = cv::Mat();
  int id = -1;
  std::vector<int> vec;

  bool srcEmpty() {
    if (src.data) return true;
    std::cout << "mat is empty: " << id << std::endl;
    return false;
  }
};
