#pragma once
#include "IData.h"
namespace {

bool AlgoBitwiseNot(IData* d) {
  if (!d->srcEmpty()) return false;

 

  cv::bitwise_not( d->src, d->dst);

  return true;
}

}  // namespace
