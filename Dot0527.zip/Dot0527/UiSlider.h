﻿#pragma once
#include <QHBoxLayout>
#include <QLabel>
#include <QSlider>
#include <QSpinBox>

class UiSlider : public QWidget {
  Q_OBJECT
 public:
  UiSlider(QString text, int min, int max, int single_step);

  int get();
  void set(int);

  std::string getText();
  void setText(QString);

 private:
  QLabel* label_;
  QSlider* slider_;
  QSpinBox* spinBox_;
 signals:
  void value_changed(int);
};
