﻿#include "UiSlider.h"

UiSlider::UiSlider(QString text, int min, int max, int single_step  ) {
  label_ = new QLabel(text);
  slider_ = new QSlider(Qt::Horizontal);
  spinBox_ = new QSpinBox;
  slider_->setRange(min, max);
  spinBox_->setRange(min, max);
  slider_->setSingleStep(single_step);
  spinBox_->setSingleStep(single_step);
  slider_->setFixedWidth(200);
  spinBox_->setFixedWidth(50);
  label_->setFixedWidth(150);
  QHBoxLayout* sub_layout = new QHBoxLayout;
  sub_layout->addWidget(spinBox_);
  sub_layout->addWidget(label_);
  QGridLayout* main_layout = new QGridLayout;
  main_layout->addLayout(sub_layout, 0, 0);
  main_layout->addWidget(slider_, 1, 0);

  connect(slider_, &QSlider::valueChanged, this, [=](int v) {
    spinBox_->setValue(v);
    emit value_changed(v);
  });

  connect(spinBox_, QOverload<int>::of(&QSpinBox::valueChanged), this,
          [=](int v) { slider_->setValue(v); });

  set(min);

  //最终显示
  this->setLayout(main_layout);
}

int UiSlider::get() { return spinBox_->value(); }

void UiSlider::set(int v) { spinBox_->setValue(v); }

void UiSlider::setText(QString text) { label_->setText(text); }
std::string UiSlider::getText() { return label_->text().toStdString(); }