#include "MainWidget.h"

MainWidget::MainWidget(QWidget* parent) : QWidget{parent} {
  init_ui();

  // _thd
  m_thd_calc = new ThdCalc;
  auto _func = [=]() { m_thd_calc->run(); };
  std::thread _thd(_func);
  _thd.detach();

  // signals - slots
  connect(btn_start, &QPushButton::clicked, this, [=]() {
    if (register_cvMap(0)) m_thd_calc->resume(true, m_list->count() - 1);
  });
  connect(btn_clear_text, &QPushButton::clicked, this,
          [=]() { system("cls"); });
  connect(m_thd_calc, &ThdCalc::sig_finished, this,
          [&](int data_id) { show_pix(data_id, 1); });

  connect(btn_add, &QPushButton::clicked, this, &MainWidget::step_add);
  connect(btn_insert, &QPushButton::clicked, this, &MainWidget::step_insert);
  connect(btn_delete, &QPushButton::clicked, this, &MainWidget::step_delete);
  connect(btn_read_all, &QPushButton::clicked, this, &MainWidget::file_read);
  connect(btn_write_all, &QPushButton::clicked, this, &MainWidget::file_write);
  connect(btn_create_by_file, &QPushButton::clicked, this,
          &MainWidget::create_by_file);
}

void MainWidget::init_ui() {
  setMinimumSize(1300, 600);

  // step_scroll
  QScrollArea* step_scroll = new QScrollArea;
  m_list = new QListWidget;
  step_scroll->setWidgetResizable(true);
  step_scroll->setWidget(m_list);

  // ctrl_widget
  QWidget* ctrl_widget = new QWidget;
  QGridLayout* ctrl_layout = new QGridLayout;
  btn_start = new QPushButton("START");
  btn_add = new QPushButton("add");
  btn_insert = new QPushButton("insert");
  btn_delete = new QPushButton("delete");
  btn_clear_text = new QPushButton("clear_text");
  btn_read_all = new QPushButton("read_all");
  btn_write_all = new QPushButton("write_all");
  btn_create_by_file = new QPushButton("create_by_file");

  ctrl_layout->addWidget(btn_add, 0, 0);
  ctrl_layout->addWidget(btn_insert, 1, 0);
  ctrl_layout->addWidget(btn_delete, 2, 0);
  ctrl_layout->addWidget(btn_start, 1, 3);
  ctrl_layout->addWidget(btn_clear_text, 3, 1);
  ctrl_layout->addWidget(btn_write_all, 4, 0);
  ctrl_layout->addWidget(btn_read_all, 5, 0);
  ctrl_layout->addWidget(btn_create_by_file, 6, 0);

  ctrl_widget->setLayout(ctrl_layout);

  // side_layout = step_scroll + ctrl_widget
  QVBoxLayout* side_layout = new QVBoxLayout;
  side_layout->addWidget(step_scroll, 15, Qt::AlignHCenter);
  side_layout->addStretch(1);
  side_layout->addWidget(ctrl_widget, 1, Qt::AlignHCenter);
  side_layout->addStretch(1);

  // mainLayout
  QHBoxLayout* mainLayout = new QHBoxLayout;
  m_stack = new QStackedWidget;
  m_view = new UiGraphicsview;
  mainLayout->addWidget(m_view, 3, Qt::AlignHCenter);
  mainLayout->addWidget(m_stack, 1, Qt::AlignHCenter);
  mainLayout->addLayout(side_layout, 1);
  mainLayout->setMargin(0);   //���ұ߾�
  mainLayout->setSpacing(0);  // ���¼��
  this->setLayout(mainLayout);

  m_choices = new UiChoices;
}

bool MainWidget::register_cvMap(int n) {
  if (m_list->count() < 1) return false;
  cv::Mat src = cv::imread("t.png");

  if (src.empty()) {
    std::cout << "register_cvMap is empty: " << n << std::endl;
    return false;
  }
  g_data[n]->src = src.clone();

  for (int i = 0; i < m_stack->count(); ++i) {
    UiVbox* w = static_cast<UiVbox*>(m_stack->widget(i));
    w->flushParam();
  }

  return true;
}

void MainWidget::step_add() {
  m_choices->exec();  // ģ̬
  UiVbox* w = m_choices->create();
  if (!w) return;
  QListWidgetItem* item = new QListWidgetItem;

  step_disconnect();  // �Ͽ��ź�
  m_stack->addWidget(w);
  m_list->addItem(item);
  step_connect();  // �ָ��ź�
}

void MainWidget::step_insert() {
  m_choices->exec();  // ģ̬
  UiVbox* w = m_choices->create();
  if (!w) return;

  QListWidgetItem* item = new QListWidgetItem;
  step_disconnect();  // �Ͽ��ź�
  m_list->insertItem(m_list->currentRow(), item);
  m_stack->insertWidget(m_stack->currentIndex(), w);

  step_connect();  // �ָ��ź�
}

void MainWidget::step_delete() {
  step_disconnect();  // �Ͽ��ź�
  int n = m_list->currentRow();
  if (n == -1) return;

  _delete_ui(n);
  step_connect();  // �ָ��ź�
}

void MainWidget::step_disconnect() {
  disconnect(m_list, 0, 0, 0);
  for (int i = 0; i < m_stack->count(); ++i) {
    UiVbox* w = static_cast<UiVbox*>(m_stack->widget(i));
    disconnect(w, 0, this, 0);
  }
}

void MainWidget::step_connect() {
  // m_list->setCurrentRow(m_list->count() - 1); // ����
  //
  for (int i = 0; i < m_list->count(); ++i) {
    UiVbox* w = static_cast<UiVbox*>(m_stack->widget(i));
    w->setId(i);
    w->flushParam();

    // ����
    std::string name = std::to_string(i) + " " + g_data[i]->name;
    m_list->item(i)->setText(QString::fromStdString(name));

    connect(w, &UiVbox::sig_show_pix, this, &MainWidget::show_pix);

    connect(w, &UiVbox::sig_call_single, this, [=](int id) {
      w->flushParam();
      m_thd_calc->resume(false, id);
    });
  }
  connect(m_list, &QListWidget::currentRowChanged, this, [=](int ui_id) {
    m_stack->setCurrentIndex(ui_id);
    show_pix(ui_id, 1);
  });
}
void MainWidget::show_pix(int id, int n) {
  cv::Mat m;
  if (n == 0)
    m = g_data[id]->src;
  else
    m = g_data[id]->dst;

  QPixmap pix = CvtMat::instance().mat2QPixmap(m);

  m_view->show_pix(pix);
}

void MainWidget::file_read() {
  for (int i = 0; i < m_list->count(); ++i) {
    UiVbox* w = static_cast<UiVbox*>(m_stack->widget(i));
    w->fileRead();
  }
}
void MainWidget::file_write() {
  MyFile f;
  f.clear();

  for (int i = 0; i < m_list->count(); ++i) {
    UiVbox* w = static_cast<UiVbox*>(m_stack->widget(i));
    w->fileWrite();
  }
}
void MainWidget::create_by_file() {
  step_disconnect();  // �Ͽ��ź�

  while (0 != m_list->count()) {
    _delete_ui(0);  //ʼ��Ϊ 0
  }
  MyFile f;
  for (int i = 0;; ++i) {
    std::string _name;
    if (!f.read(std::to_string(i), "name", _name)) break;
    std::cout << _name << std::endl;
    UiVbox* w = m_choices->create(_name);
    if (!w) break;

    QListWidgetItem* item = new QListWidgetItem;
    m_stack->addWidget(w);
    m_list->addItem(item);
  }

  step_connect();
  file_read();
}

void MainWidget::_delete_ui(int i) {
  QListWidgetItem* item = m_list->item(i);
  m_list->removeItemWidget(item);
  delete item;
  QWidget* widget = m_stack->widget(i);
  m_stack->removeWidget(widget);
  delete widget;
}