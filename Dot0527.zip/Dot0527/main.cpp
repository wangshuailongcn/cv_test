
#include <QtWidgets/QApplication>

#include "MainWidget.h"
#include "Pch.h"
struct IData;
std::unordered_map<int, IData*> g_data;
std::unordered_map<int, std::function<bool(IData*)>> g_fn;
 
 

int main(int argc, char* argv[]) {
  QApplication a(argc, argv);
   MainWidget w;
   w.show();
  

  return a.exec();
}
