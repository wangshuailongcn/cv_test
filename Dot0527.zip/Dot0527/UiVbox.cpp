#pragma once
#include "UiVbox.h"

UiVbox::UiVbox() {
  m_layout = new QVBoxLayout;
  m_data = new IData;
}
UiVbox::~UiVbox() {}

UiVbox* UiVbox::getBox() { return this; }

void UiVbox::add_1(int id, QString text, int min, int max,
                   int single_step) {


  UiSlider* w = new UiSlider(text,min,max, single_step );
  m_layout->addWidget(w);
  m_data->vec[id] = w->get();
  connect(w, &UiSlider::value_changed, this, [=](int) {
    if (!ck_continue->isChecked()) return;
    m_data->vec[id] = w->get();
    emit sig_call_single(m_data->id);
  });
}

void UiVbox::add(int id, QString text, int min, int max,
                 int single_step) {
  add_1(id, text, min, max, single_step);
  m_layout->addStretch();
  QWidget* w = new QWidget;

  QVBoxLayout* main_layout = new QVBoxLayout;

  main_layout->addWidget(makeCommonUi());
  main_layout->addLayout(m_layout);
  m_layout->addStretch();
  this->setLayout(main_layout);
}

void UiVbox::removeAll() {
  while (true) {
    QLayoutItem* item = m_layout->takeAt(0);
    if (!item) break;
    if (!item->widget()) break;
    m_layout->removeItem(item);
    delete item;
  }
}

void UiVbox::flushParam() {
  for (int i = 0; i < m_layout->count(); ++i) {
    QLayoutItem* item = m_layout->itemAt(i);
    if (!item) break;
    UiSlider* w = static_cast<UiSlider*>(item->widget());
    if (!w) break;

    m_data->vec[i] = w->get();  // ֻ��
  }
}

QWidget* UiVbox::makeCommonUi() {
  QVBoxLayout* mainLayout = new QVBoxLayout;
  btn_single = new QPushButton("single_start");
  btn_write = new QPushButton("write");
  btn_read = new QPushButton("read");
  btn_src = new QPushButton("src");
  btn_dst = new QPushButton("dst");
  ck_continue = new QCheckBox(QStringLiteral("single_continue"));

  connect(btn_single, &QPushButton::clicked, this,
          [=]() { emit sig_call_single(m_data->id); });
  connect(btn_src, &QPushButton::clicked, this,
          [=]() { emit sig_show_pix(m_data->id, 0); });
  connect(btn_dst, &QPushButton::clicked, this,
          [=]() { emit sig_show_pix(m_data->id, 1); });

  connect(btn_write, &QPushButton::clicked, this, [=]() { fileWrite(); });
  connect(btn_read, &QPushButton::clicked, this, [=]() { fileRead(); });
  QWidget* w = new QWidget;
  QVBoxLayout* _box = new QVBoxLayout;
  _box->addWidget(btn_write);
  _box->addWidget(btn_read);
  _box->addWidget(ck_continue);
  _box->addWidget(btn_single);
  _box->addWidget(btn_src);
  _box->addWidget(btn_dst);

  w->setLayout(_box);
  return w;
}

void UiVbox::fileWrite() {
  MyFile f;
  std::string appName{std::to_string(m_data->id)};
  flushParam();
  for (int i = 0; i < m_layout->count(); ++i) {
    QLayoutItem* item = m_layout->itemAt(i);
    if (!item) break;
    UiSlider* w = static_cast<UiSlider*>(item->widget());
    if (!w) break;
    if (i == 0) f.write(appName, "name", m_data->name);
    f.write(appName, std::to_string(i), m_data->vec[i]);
  }
}
void UiVbox::fileRead() {
  ck_continue->setChecked(false);
  MyFile f;
  std::string appName{std::to_string(m_data->id)};

  for (int i = 0; i < m_layout->count(); ++i) {
    QLayoutItem* item = m_layout->itemAt(i);
    if (!item) break;
    UiSlider* w = static_cast<UiSlider*>(item->widget());
    if (!w) break;
    if (i == 0) f.read(appName, "name", m_data->name);

    f.read(appName, std::to_string(i), m_data->vec[i]);
    w->set(m_data->vec[i]);
  }
}