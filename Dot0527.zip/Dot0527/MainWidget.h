#pragma once

#include <qboxlayout.h>
#include <qlistwidget.h>
#include <qpushbutton.h>
#include <qstackedwidget.h>

#include "CvtMat.h"
#include "ThdCalc.h"
#include "UiChoices.h"
#include "UiGraphicsview.h"


class MainWidget : public QWidget {
	Q_OBJECT

public:
	MainWidget( QWidget* parent = nullptr );

private:
	UiGraphicsview* m_view;
	UiChoices* m_choices;
	ThdCalc* m_thd_calc;
	QListWidget* m_list;
	QStackedWidget* m_stack;
	QPushButton* btn_start, * btn_clear_text;
	QPushButton* btn_add, * btn_insert, * btn_delete;
	QPushButton* btn_read_all, * btn_write_all;
	QPushButton* btn_create_by_file;
	 

	void _delete_ui( int i );  // ��������
	bool register_cvMap( int n );
	void init_ui();
	void show_pix( int data_id, int mat_serial );
	void step_add();
	void step_insert();
	void step_delete();
 
	void step_disconnect();
	void step_connect();
	void file_read();
	void file_write();
	void create_by_file();
};
