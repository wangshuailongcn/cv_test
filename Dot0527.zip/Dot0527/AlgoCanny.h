#pragma once
#include "IData.h"
namespace {

bool AlgoCanny(IData* d) {
  if (!d->srcEmpty()) return false;

 
  int threshold1 = d->vec[0];
  int threshold2 = d->vec[1];

  cv::Canny(d->src, d->dst, threshold1, threshold2);

  return true;
}

}  // namespace