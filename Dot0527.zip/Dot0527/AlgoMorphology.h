#pragma once
#include "Algo_Macro.h"
#include "IData.h"
// QString text{ "" };
// if (n == 0)
// text = "0MORPH_ERODE";
// else if (n == 1)
// text = "1MORPH_DILATE";
// else if (n == 2)
// text = "2MORPH_OPEN";
// else if (n == 3)
// text = "3MORPH_CLOSE";
// else if (n == 4)
// text = "4MORPH_GRADIENT";
// else if (n == 5)
// text = "5MORPH_TOPHAT";
// else if (n == 6)
// text = "6MORPH_BLACKHAT";
// else if (n == 7)
// text = "7MORPH_HITMISS";
// else if (n == 8)
// text = "_MORPH_boundary";

namespace {

bool AlgoMorphology(IData* d) {
  if (!d->srcEmpty()) return false;
  int i = 0;
  // cv::Mat src = d->src;
  // cv::Mat dst = d->dst;
  int k = d->vec[i++] * 2 + 1;
  int op = d->vec[i++];
  int iterations = d->vec[2];
  cv::Mat element = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(k, k),
                                              cv::Point(-1, -1));

  // ��̬ѧ��ȡ
  if (op == _MORPH_boundary) {
    erode(d->src, d->dst, element);
    d->dst = d->src - d->dst;
    return true;
  }

  cv::morphologyEx(d->src, d->dst, op, element, cv::Point(-1, -1), iterations);

  return true;
}

}  // namespace