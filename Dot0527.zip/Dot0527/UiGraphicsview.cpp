﻿#include "UiGraphicsview.h"

UiGraphicsview::UiGraphicsview(QWidget* parent) : QGraphicsView(parent) {
	myScene = new QGraphicsScene(this);
	this->setScene(myScene);
	myPixmapItem = new QGraphicsPixmapItem();
	myScene->addItem(myPixmapItem);
	rect1 = new QGraphicsRectItem();
	myScene->addItem(rect1);
	textFirstPos = new QGraphicsTextItem;
	textLastPos = new QGraphicsTextItem;
	myScene->addItem(textFirstPos);
	myScene->addItem(textLastPos);

	m_pix = new QPixmap(800, 600);
	m_pix->fill(Qt::black);
	show_pix(*m_pix);

}

void UiGraphicsview::show_pix(const QPixmap& pix) {
	if (!pix) {
		myPixmapItem->setPixmap(*m_pix);
		return;
	}
	myPixmapItem->setPixmap(
		pix.scaled(pix.size(), Qt::KeepAspectRatioByExpanding));
}

void UiGraphicsview::wheelEvent(QWheelEvent* event) {
	qreal factor = 1.0 + event->delta() / 800.0;
	if (factor < 0.8 || factor > 1.5) {
		return;
	}
	this->scale(factor, factor);
}

void UiGraphicsview::mouseMoveEvent(QMouseEvent* event) {
	if (myDrawType == drawNull) {
		if (!bMouseE) {
			QPointF mouseDist =
				this->mapToScene(event->pos()) - this->mapToScene(m_lastMousePos);
			mouseDist *= this->transform().m11();
			this->setTransformationAnchor(QGraphicsView::AnchorUnderMouse);
			this->centerOn(this->mapToScene(
				QPoint(this->viewport()->rect().width() / 2 - mouseDist.x(),
					this->viewport()->rect().height() / 2 - mouseDist.y())));
			this->setTransformationAnchor(QGraphicsView::AnchorViewCenter);
			m_lastMousePos = event->pos();
			return;
		}
	}
	if (myDrawType == drawRect) {
		if (!bMouseE) {
			m_lastMousePos = event->pos();
			QPointF firstPosScene = this->mapToScene(m_firstMousePos);
			QPointF lastPosScene = this->mapToScene(m_lastMousePos);
			QRect rect(firstPosScene.x(), firstPosScene.y(),
				lastPosScene.x() - firstPosScene.x(),
				lastPosScene.y() - firstPosScene.y());
			rect1->setRect(rect);
			QPen pen;
			pen.setColor("#0000FF");
			pen.setWidth(2);
			rect1->setPen(pen);
			QString text1 = QString::asprintf("firstPos: %.1f,%.1f",
				firstPosScene.x(), firstPosScene.y());
			QString text2 = QString::asprintf("lastPos: %.1f,%.1f", lastPosScene.x(),
				lastPosScene.y());
			textFirstPos->setPlainText(text1);
			textLastPos->setPlainText(text2);
			// textItem->setFont(QFont("华文琥珀",12));
			textFirstPos->setDefaultTextColor("#FF0000");
			textLastPos->setDefaultTextColor("#FF0000");
			// textItem->setFlags(QGraphicsItem::ItemIsMovable|QGraphicsItem::ItemIsSelectable);
			textFirstPos->setPos(firstPosScene);
			textLastPos->setPos(lastPosScene);
		}
	}
}

void UiGraphicsview::mousePressEvent(QMouseEvent* event) {
	if (bMouseE) {
		bMouseE = false;
		m_firstMousePos = event->pos();
		m_lastMousePos = event->pos();  //初始偏移
	}
}

void UiGraphicsview::mouseReleaseEvent(QMouseEvent* event) {
	bMouseE = true;
	m_lastMousePos = event->pos();
	// qDebug()<<"m_lastMousePos"<<m_lastMousePos;
}

void UiGraphicsview::mouseDoubleClickEvent(QMouseEvent*) {
	this->resetTransform();
}
void UiGraphicsview::setDrawType(int type) { myDrawType = type; }
