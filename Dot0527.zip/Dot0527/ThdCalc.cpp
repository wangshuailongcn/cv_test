#include "ThdCalc.h"
bool ThdCalc::m_pause = false;

void ThdCalc::run() {
  while (true) {
    {
      std::unique_lock<std::mutex> lock(m_mutex);
      m_cv.wait(lock, [this] { return !m_pause; });
    }
    do_calc(all_, n_);

    m_pause = true;

    // std::this_thread::sleep_for(std::chrono::milliseconds(100));
  }
}

void ThdCalc::resume(bool all, int n) {
  std::unique_lock<decltype(m_mutex)> lck(m_mutex);
  m_pause = false;
  all_ = all;
  n_ = n;
  m_cv.notify_one();
}

bool ThdCalc::is_working() { return !m_pause; }

bool ThdCalc::do_calc(bool all, int n) {
  if (n < 0) return false;
  cv::Mat cache;
  if (all) {
    for (int i = 0; i <= n; ++i) {
      IData* d = g_data[i];
      try {
        if (i != 0) d->src = cache;
        g_fn[i](d);  // i
      } catch (...) {
        std::cerr << "ִ�м��� error " << i << std::endl;
        return false;
      }
      if (i != n)  cache=d->dst ;
    }
    emit sig_finished(n_);
    return true;
  }
  // -------------------------------------
  IData* d = g_data[n];  // n
  try {
    g_fn[n](d);
  } catch (...) {
    std::cerr << "ִ�м��� x  " << n << std::endl;
    return false;
  }
  // -------------------------------------
 
  ++n;
  if (g_data[n]) g_data[n]->src = d->dst;
  emit sig_finished( n_ );
  return true;
}
